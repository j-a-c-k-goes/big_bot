# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['big_bot']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp==3.7.4.post0',
 'async-timeout==3.0.1',
 'attrs==22.1.0',
 'certifi>=2022.12.7,<2023.0.0',
 'chardet==4.0.0',
 'discord-py>=2.1.0,<3.0.0',
 'idna==3.4',
 'meson==0.63.2',
 'multidict==6.0.2',
 'python-discord==1.7.3',
 'python-dotenv==0.21.0',
 'typing-extensions==4.3.0',
 'yarl==1.8.1']

setup_kwargs = {
    'name': 'bigbot',
    'version': '0.2.0',
    'description': '!bigbot',
    'long_description': '# 🤖 !BigBot\n\nBig bot bigs up the [W3BBIE Server](https://discord.gg/ZYKGW892)\n\n## 🧩 Attributions\n* [Bot Concept](https://discordapp.com/users/bigtrav.eth#4250)\n* [Bot Collaborator, Refactor, Additional Design](https://discordapp.com/users/jackjackjack#7167)\n* [Bot Keeper](https://discordapp.com/users/Kyn#3709)\n\n## 🛠 Installation\n\n### 🐍 Python3\n* Do I have Python3?\n\t- Open your terminal window / ide\n\t-  `python3 --version`\n* I do not have Python3\n\t- *Install Python3, See next section*\n\n### 🤔 Where Do I Get Python3?\n\n* **🔗 https://realpython.com/installing-python/**\n* **🔗https://opensource.com/article/19/5/python-3-default-mac**\n* [Python for Windows](https://www.python.org/downloads/windows/)\n\n*Note: there are other links, methods as well. just run a quick itnernet search, or ask ChatGPT)*\n\n### ✅ Requirements\n\n* Install via the `requirements.txt` file\n\t-  `pip install -r requirements.txt`\n* Install via Poetry Package Manager\n\t- `poetry install`\n\n### 🔓 🌍 The Environement File\n* Find the `env_example` file, it is in the `/big_bot/` sub-directoryroot directory of the project\n\t- `cd ~ big_bot/big_bot`\n\t- `open env_example` (in an IDE or Text Editor)\n* Follow the instructions locatated withing the file to update with proper credentials, and on how to save the file as a hidden file. \n\n### 🚀 Launching The Bot\n* Run the script in the `big_bot/big_bot` directory\n\t- `cd ~ big_bot/big_bot`\n\t- `poetry shell`\n\t\t+ not neccessary if you installed via `requirements.txt`\n\t- `python3 app.py`\n',
    'author': 'trav',
    'author_email': 'heytrav205@gmail.com> jack <jack@flnpb.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
